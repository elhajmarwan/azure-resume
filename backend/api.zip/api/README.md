# Your API lives here

## Dependance
- install [Functions Core Tools](https://learn.microsoft.com/fr-fr/azure/azure-functions/functions-run-local?tabs=windows%2Cisolated-process%2Cnode-v4%2Cpython-v2%2Chttp-trigger%2Ccontainer-apps&pivots=programming-language-csharp)

if you want to run localy your code