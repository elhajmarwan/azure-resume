using System;
using System.IO;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Azure.WebJobs;
using Microsoft.Azure.WebJobs.Extensions.Http;
using Microsoft.AspNetCore.Http;
using Microsoft.Extensions.Logging;
using Newtonsoft.Json;
using Microsoft.Azure.Functions.Worker;


namespace Company.Function
{
    public static class GetResumeCounter
    {
        [FunctionName("GetResumeCounter")]
        public static async Task<IActionResult> Run(
            [HttpTrigger(AuthorizationLevel.Function, "get", "post", Route = null)] HttpRequest req,

            [CosmosDBInput(
                databaseName: "Counter_db",
                containerName: "Counter_container",
                Connection = "CosmosDbConnectionSetting",
                Id = "1",  // ID du document à lire
                PartitionKey = "1"  // Clé de partition
            )] Counter counter, // Type du document à lier

            ILogger log)
        {
            log.LogInformation("Processing GetResumeCounter.");

            if (counter == null)
            {
                return new NotFoundObjectResult("Document not found.");
            }

            // Exemple de traitement
            counter.Count += 1;

            return new OkObjectResult(counter);
        }
        // [FunctionName("GetResumeCounter")]
        // public static async Task<IActionResult> Run(
        //     [HttpTrigger(AuthorizationLevel.Function, "get", "post", Route = null)] HttpRequest req,

        //     // Input Binding: Read the Counter document with a specific Id and PartitionKey
        //     [CosmosDBInput(
        //         databaseName: "Counter_db",
        //         containerName: "Counter_container",
        //         Connection = "CosmosDbConnectionSetting",
        //         Id = "1",                          // Set your document ID
        //         PartitionKey = "1"                 // Set your partition key
        //     )] Counter counter,

        //     // Output Binding: Write the updated Counter back to Cosmos DB
        //     [CosmosDB(
        //         databaseName: "Counter_db",
        //         containerName: "Counter_container",
        //         Connection = "CosmosDbConnectionSetting"
        //     )] IAsyncCollector<Counter> updatedCounterCollector,

        //     ILogger log)
        // {
        //     log.LogInformation("C# HTTP trigger function processed a request.");

        //     if (counter == null)
        //     {
        //         return new NotFoundObjectResult("Counter document not found.");
        //     }

        //     // Increment the counter
        //     counter.Count += 1;

        //     // Save the updated counter back to Cosmos DB
        //     await updatedCounterCollector.AddAsync(counter);

        //     // Return the updated counter as a response
        //     var responseMessage = $"The counter value has been updated to {counter.Count}";

        //     return new OkObjectResult(responseMessage);
        // }
    }

public class Counter
{
    [JsonProperty("id")]
    public string Id { get; set; }

    // [JsonProperty("partitionKey")]
    // public string PartitionKey { get; set; }

    [JsonProperty("count")]
    public int Count { get; set; }
}

}



// // using System;
// // using System.IO;
// // using System.Threading.Tasks;
// // using Microsoft.AspNetCore.Mvc;
// // using Microsoft.Azure.WebJobs;
// // using Microsoft.Azure.WebJobs.Extensions.Http;
// // using Microsoft.AspNetCore.Http;
// // using Microsoft.Extensions.Logging;
// // using Newtonsoft.Json;
// // using Microsoft.Azure.Functions.Worker;
// // using System.Net.Http;
// // using System.Text;

// // namespace Company.Function
// // {
// //     public static class GetResumeCounter
// //     {
// //         [FunctionName("GetResumeCounter")]
// //         public static HttpResponseMessage Run(
// //             [HttpTrigger(AuthorizationLevel.Function, "get", "post", Route = null)] HttpRequest req,
// //             [CosmosDBTrigger(databaseName: "Counter_db", containerName: "Counter_container", Connection  = "AzureResumeConnectionString")]  Counter counter,
// //             // [CosmosDBTrigger(databaseName: "Counter_db", containerName: "Counter_container", Connection  = "AzureResumeConnectionString")] out Counter updatedcounter,
// //             // [CosmosDBInput(databaseName: "Counter_db", containerName: "Counter_container", Connection  = "AzureResumeConnectionString",Id = "1", PartitionKey = "1" )] Counter counter,
// //             // [CosmosDBInput(databaseName: "Counter_db", containerName: "Counter_container", Connection  = "AzureResumeConnectionString",Id = "1", PartitionKey = "1" )] out Counter updatedcounter,   
// //             ILogger log)
// //         {
// //             log.LogInformation("C# HTTP trigger function processed a request.");

// //             var updatedcounter = counter;
// //             updatedcounter.Count +=1;

// //             var json = JsonConvert.SerializeObject(counter);
            

// //             return new HttpResponseMessage(System.Net.HttpStatusCode.OK)
// //             {
// //                 Content = new StringContent(json,Encoding.UTF8, "application/json")
// //             };

// //         }
// //     }
// // }


// using System;
// using System.IO;
// using System.Threading.Tasks;
// using Microsoft.AspNetCore.Mvc;
// using Microsoft.Azure.WebJobs;
// using Microsoft.Azure.WebJobs.Extensions.Http;
// using Microsoft.AspNetCore.Http;
// using Microsoft.Extensions.Logging;
// using Newtonsoft.Json;
// using Microsoft.Azure.Functions.Worker;

// namespace Company.Function
// {
//     public static class GetResumeCounter
//     {
//         [FunctionName("GetResumeCounter")]
//         public static async Task<IActionResult> Run(
//             [HttpTrigger(AuthorizationLevel.Function, "get", "post", Route = null)] HttpRequest req,
//             [CosmosDBTrigger(databaseName: "Counter_db", containerName: "Counter_container", Connection  = "AzureResumeConnectionString")]  Counter counter,
//             // [CosmosDBTrigger(databaseName: "AzureResume", containerName: "Counter", Connection  = "AzureResumeConnectionString", LeaseContainerName = "leases", CreateLeaseContainerIfNotExists =true)] Counter counter,
//             // [CosmosDB( databaseName: "AzureResume",collectionName:"iowa_sales", ConnectionStringSetting = "cosmosdb_DOCUMENTDB")]  IAsyncCollector<IowaSales> output,
            
//             // [CosmosDBTrigger(databaseName:"AzureResume",containerName: "Counter",Connection = "AzureResumeConnectionString", Id = "1")] Counter counter,
//             // [CosmosDBOutput(databaseName:"AzureResume", containerName: "Counter",Connection = "AzureResumeConnectionString",ContainerThroughput = 1,CreateIfNotExists = false)] Counter updatedCounter,
//             ILogger log)
//         {
//             log.LogInformation("C# HTTP trigger function processed a request.");

//             string name = req.Query["name"];

//             string requestBody = await new StreamReader(req.Body).ReadToEndAsync();
//             dynamic data = JsonConvert.DeserializeObject(requestBody);
//             name = name ?? data?.name;

//             string responseMessage = string.IsNullOrEmpty(name)
//                 ? "This HTTP triggered function executed successfully. Pass a name in the query string or in the request body for a personalized response."
//                 : $"Hello, {name}. This HTTP triggered function executed successfully.";

//             return new OkObjectResult(responseMessage);
//         }
//     }
// }
